from django.urls import path
from .views import donorregdisplay
#, donorregsuccess

urlpatterns = [
    path('oooooo', donorregdisplay, name='dregsite'),
    path('donors', donorregdisplay, name='dregdisplay')
]