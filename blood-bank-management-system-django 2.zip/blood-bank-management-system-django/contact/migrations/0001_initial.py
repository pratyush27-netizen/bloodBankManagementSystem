

from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='ContactPageBody',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('id_contact', models.IntegerField(blank=True, null=True)),
                ('title', models.CharField(blank=True, max_length=20, null=True)),
                ('contact_text', models.TextField(blank=True, null=True)),
            ],
        ),
    ]
