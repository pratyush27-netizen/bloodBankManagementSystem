

from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='HomePageBody',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('id_vision', models.IntegerField(blank=True, null=True)),
                ('title', models.CharField(blank=True, max_length=20, null=True)),
                ('body_img', models.ImageField(upload_to='home_body')),
                ('body_text', models.TextField(blank=True, null=True)),
            ],
        ),
        migrations.CreateModel(
            name='HomePageSlider',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('id_number', models.IntegerField(blank=True, null=True)),
                ('title', models.CharField(blank=True, max_length=20, null=True)),
                ('slider_1', models.ImageField(upload_to='slider')),
                ('slider_2', models.ImageField(upload_to='slider')),
                ('slider_3', models.ImageField(upload_to='slider')),
            ],
        ),
    ]
